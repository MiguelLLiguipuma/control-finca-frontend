import { createRouter, createWebHistory } from 'vue-router';
import { useAuthStore } from '@/stores/auth/authStore';
import RegistroEnfunde from '@/views/RegistroEnfunde.vue';
import RegistroEmpresa from '@/views/EmpresasView.vue';
import DashboardReportes from '../views/reportes/dashboardReportes.vue';
import LoginView from '@/views/Login.vue';
import FincasView from '../views/FincaView.vue';

// 1. IMPORTAR LA NUEVA VISTA DE COSECHA
import RegistroCosecha from '@/views/cosecha/RegistroCosechaView.vue';

const routes = [
	{
		path: '/login',
		name: 'Login',
		component: LoginView,
		meta: { public: true },
	},
	{
		path: '/',
		redirect: '/reportes',
	},
	{
		path: '/registro-enfunde',
		name: 'Enfunde',
		component: RegistroEnfunde,
		meta: { requiresAuth: true },
	},
	// 2. AÑADIR LA RUTA DE COSECHA
	{
		path: '/registro-cosecha',
		name: 'Cosecha',
		component: RegistroCosecha,
		meta: { requiresAuth: true },
	},
	{
		path: '/reportes',
		name: 'Reportes',
		component: DashboardReportes,
		meta: { requiresAuth: true },
	},
	{
		path: '/empresas',
		name: 'Empresas',
		component: RegistroEmpresa,
		meta: { requiresAuth: true },
	},
	{
		path: '/fincas',
		name: 'Fincas',
		component: FincasView,
		meta: { requiresAuth: true },
	},
	{
		path: '/:pathMatch(.*)*',
		redirect: '/reportes',
	},
];

const router = createRouter({
	history: createWebHistory(),
	routes,
});

router.beforeEach((to, from, next) => {
	const authStore = useAuthStore();

	if (to.matched.length === 0) {
		return next('/reportes');
	}

	const isPublic = to.matched.some((record) => record.meta.public);
	const requiresAuth = to.matched.some((record) => record.meta.requiresAuth);

	if (requiresAuth && !authStore.isAuthenticated) {
		next('/login');
	} else if (isPublic && authStore.isAuthenticated) {
		next('/reportes');
	} else {
		next();
	}
});

export default router;
