import { defineStore } from 'pinia';
import { cosechaService } from '../../services/cosecha/cosechaService.js';
import { useUIStore } from '../../stores/uiStore.js';

export const useCosechaStore = defineStore('cosecha', {
	state: () => ({
		loading: false,
		saldosPendientes: [], // Datos de backend + control de formulario
		error: null,
	}),

	actions: {
		// ===============================
		// Cargar saldos de campo por finca
		// ===============================
		async cargarSaldos(fincaId) {
			if (!fincaId) return;

			this.loading = true;
			this.error = null;

			try {
				const data = await cosechaService.getBalance(fincaId);

				// Normalización + estado limpio
				this.saldosPendientes = data.map((item) => ({
					...item,
					cantidad_a_cosechar: 0,
					rechazo: 0,
				}));
			} catch (err) {
				this.error = err?.message || 'Error desconocido';
				useUIStore().showError('Error al cargar saldos de campo');
			} finally {
				this.loading = false;
			}
		},

		// ===============================
		// Reset explícito del digitado
		// ===============================
		resetCosecha() {
			this.saldosPendientes.forEach((s) => {
				s.cantidad_a_cosechar = 0;
				s.rechazo = 0;
			});
		},

		// ===============================
		// Enviar cosecha (VALIDADA)
		// ===============================
		async enviarCosecha(fincaId, fecha, usuarioId) {
			const uiStore = useUIStore();

			// Normalizamos valores y validamos
			const excedidos = this.saldosPendientes.filter((s) => {
				const buenos = Number(s.cantidad_a_cosechar) || 0;
				const rechazo = Number(s.rechazo) || 0;

				// Protección adicional
				if (buenos < 0 || rechazo < 0) return true;

				return buenos + rechazo > s.saldo_en_campo;
			});

			if (excedidos.length > 0) {
				uiStore.showError(
					'Existen semanas donde la cosecha supera el saldo disponible',
				);
				return false;
			}

			// Construcción de payload limpio
			const detalles = this.saldosPendientes
				.filter(
					(s) =>
						(Number(s.cantidad_a_cosechar) || 0) > 0 ||
						(Number(s.rechazo) || 0) > 0,
				)
				.map((s) => ({
					calendario_id: s.calendario_id,
					cantidad_racimos: Number(s.cantidad_a_cosechar) || 0,
					cantidad_rechazo: Number(s.rechazo) || 0,
				}));

			if (detalles.length === 0) {
				uiStore.showWarning('No hay datos de cosecha para registrar');
				return false;
			}

			this.loading = true;
			this.error = null;

			try {
				await cosechaService.registrarLiquidacion({
					finca_id: fincaId,
					fecha,
					usuario_id: usuarioId,
					detalles,
				});

				uiStore.showSuccess('Cosecha registrada y saldos actualizados');

				// Refrescamos saldos (reset implícito)
				await this.cargarSaldos(fincaId);
				return true;
			} catch (err) {
				this.error = err?.message || 'Error al guardar cosecha';
				uiStore.showError('Error al guardar la cosecha');
				return false;
			} finally {
				this.loading = false;
			}
		},
	},
});
