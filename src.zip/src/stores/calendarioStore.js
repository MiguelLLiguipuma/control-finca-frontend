import { defineStore } from 'pinia';
import api from '@/services/api';

export const useCalendarioStore = defineStore('calendario', {
	state: () => ({ calendarios: [] }),
	actions: {
		async obtenerCalendarios() {
			const { data } = await api.get('/calendarios');
			this.calendarios = data;
			return data;
		},
	},
});
